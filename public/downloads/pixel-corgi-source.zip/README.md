# Codex Pet Club source kit

This ZIP is an editable concept source kit from Codex Pet Club. It contains a
portable `pet.json` definition with the character's identity, palette, states,
and license so you can remix the idea without reverse-engineering a preview.

## Files

- `pet.json` — editable character definition and state notes.
- `LICENSE` — the license selected by the original author.
- `README.md` — this guide.

## Important

This is a creative starter kit, not a finished Codex v2 install package. A
finished Codex v2 pet also needs a validated 8 x 11 animation atlas, a
`spritesheet.webp`, and `spriteVersionNumber: 2` packaging. Keep the author and
license fields when you publish a remix.

## Remix workflow

1. Change the palette and personality fields in `pet.json`.
2. Use the nine state notes as your animation brief.
3. Produce and validate the full Codex v2 sprite atlas.
4. Package the final `pet.json` and `spritesheet.webp` together.
5. Share your version with a preview and explicit license.
